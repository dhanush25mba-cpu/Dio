package com.dhanu.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF0B0914)
private val Panel = Color(0xFF171326)
private val Purple = Color(0xFF9B5CFF)
private val Pink = Color(0xFFFF5CC8)
private val Soft = Color(0xFFEDE7FF)
private val Muted = Color(0xFFAAA2C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DhanuApp() }
    }
}

data class Person(val uid: String = "", val name: String = "", val email: String = "")
data class ChatMessage(val id: String = "", val senderId: String = "", val text: String = "", val sentAt: Long = 0L)
data class ChatRow(val id: String = "", val otherUid: String = "", val otherName: String = "", val lastMessage: String = "")

@Composable
fun DhanuApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var selected by remember { mutableStateOf<ChatRow?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Ink, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (user == null) AuthScreen(
                onSignedIn = { user = auth.currentUser },
                onError = { }
            ) else if (selected == null) InboxScreen(
                uid = user!!.uid,
                onOpen = { selected = it },
                onSignOut = { auth.signOut(); user = null }
            ) else ConversationScreen(
                me = user!!.uid,
                chat = selected!!,
                onBack = { selected = null }
            )
        }
    }
}

@Composable
fun BrandMark(modifier: Modifier = Modifier, size: Int = 86) {
    val transition = rememberInfiniteTransition(label = "dhanu-ring")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(6500, easing = LinearEasing)), label = "rotation")
    val pulse by transition.animateFloat(0.96f, 1.06f, infiniteRepeatable(tween(1300), RepeatMode.Reverse), label = "pulse")
    Box(modifier.size(size.dp).scale(pulse), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize().rotate(rotation).border(2.dp, Brush.sweepGradient(listOf(Purple, Pink, Color.Cyan, Purple)), CircleShape))
        Box(Modifier.fillMaxSize(0.82f).background(Brush.linearGradient(listOf(Color(0xFF39206C), Color(0xFF151026))), CircleShape), contentAlignment = Alignment.Center) {
            Text("D", fontSize = (size * .48).sp, fontWeight = FontWeight.Black, color = Soft)
        }
    }
}

@Composable
fun AuthScreen(onSignedIn: () -> Unit, onError: (String) -> Unit) {
    var isRegister by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val db = remember { FirebaseFirestore.getInstance() }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF21133D), Ink, Ink))).padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        BrandMark(size = 104)
        Spacer(Modifier.height(18.dp))
        Text("DHANU", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Soft, letterSpacing = 5.sp)
        Text("Connect Beyond Limits", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(34.dp))
        Text(if (isRegister) "Create your account" else "Welcome back", color = Soft, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        if (isRegister) DhanuField(name, { name = it }, "Your name")
        DhanuField(email, { email = it }, "Email address", keyboard = KeyboardType.Email)
        DhanuField(password, { password = it }, "Password", secret = true)
        if (message.isNotBlank()) Text(message, color = Color(0xFFFF9CBA), fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Button(onClick = {
            if (email.isBlank() || password.length < 6 || (isRegister && name.isBlank())) { message = "Enter valid details. Password must be at least 6 characters."; return@Button }
            busy = true; message = ""
            val a = FirebaseAuth.getInstance()
            if (isRegister) a.createUserWithEmailAndPassword(email.trim(), password).addOnSuccessListener { result ->
                val uid = result.user!!.uid
                db.collection("users").document(uid).set(mapOf("uid" to uid, "name" to name.trim(), "email" to email.trim().lowercase(), "createdAt" to FieldValue.serverTimestamp()))
                    .addOnSuccessListener { busy = false; onSignedIn() }.addOnFailureListener { busy = false; message = it.localizedMessage ?: "Could not save profile" }
            }.addOnFailureListener { busy = false; message = it.localizedMessage ?: "Registration failed" }
            else a.signInWithEmailAndPassword(email.trim(), password).addOnSuccessListener { busy = false; onSignedIn() }.addOnFailureListener { busy = false; message = it.localizedMessage ?: "Login failed" }
        }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple), shape = RoundedCornerShape(16.dp)) {
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp) else Text(if (isRegister) "CREATE ACCOUNT" else "SIGN IN", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
        TextButton(onClick = { isRegister = !isRegister; message = "" }) { Text(if (isRegister) "Already have an account? Sign in" else "New to DHANU? Create account", color = Soft) }
    }
}

@Composable
fun DhanuField(value: String, onValue: (String) -> Unit, hint: String, keyboard: KeyboardType = KeyboardType.Text, secret: Boolean = false) {
    OutlinedTextField(value, onValue, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp), placeholder = { Text(hint, color = Muted) }, singleLine = true, visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, keyboardOptions = KeyboardOptions(keyboardType = keyboard), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Soft, unfocusedTextColor = Soft, focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF45385F), cursorColor = Pink, focusedContainerColor = Panel, unfocusedContainerColor = Panel), shape = RoundedCornerShape(14.dp))
}

@Composable
fun InboxScreen(uid: String, onOpen: (ChatRow) -> Unit, onSignOut: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var chats by remember { mutableStateOf<List<ChatRow>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Person>>(emptyList()) }
    var error by remember { mutableStateOf("") }
    DisposableEffect(uid) {
        val listener = db.collection("chats").whereArrayContains("participants", uid).addSnapshotListener { snap, e ->
            if (e != null) { error = e.localizedMessage ?: "Unable to load chats"; return@addSnapshotListener }
            val rows = snap?.documents.orEmpty().map { d ->
                val participants = d.get("participants") as? List<*> ?: emptyList<Any>()
                val other = participants.filterIsInstance<String>().firstOrNull { it != uid } ?: ""
                ChatRow(d.id, other, d.getString("otherName_$uid") ?: "DHANU user", d.getString("lastMessage") ?: "Say hello")
            }
            chats = rows
        }
        onDispose { listener.remove() }
    }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17102A), Ink))).padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            BrandMark(size = 48); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text("DHANU", color = Soft, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp); Text("MESSAGES", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp) }
            IconButton(onClick = onSignOut) { Icon(Icons.Default.Logout, "Sign out", tint = Muted) }
        }
        DhanuField(search, { search = it; error = "" }, "Search people by email")
        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = {
                if (!search.contains("@")) { error = "Enter the person's full email address"; return@TextButton }
                db.collection("users").whereEqualTo("email", search.trim().lowercase()).limit(10).get().addOnSuccessListener { snap ->
                    results = snap.documents.mapNotNull { d -> Person(d.id, d.getString("name") ?: "DHANU user", d.getString("email") ?: "") }.filter { it.uid != uid }
                    if (results.isEmpty()) error = "No user found. Ask them to create a DHANU account."
                }.addOnFailureListener { error = it.localizedMessage ?: "Search failed" }
            }) { Icon(Icons.Default.PersonAdd, null, tint = Pink); Spacer(Modifier.width(5.dp)); Text("Find people", color = Soft) }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9CBA), fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
        AnimatedVisibility(results.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp)) {
                Text("PEOPLE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                results.forEach { person ->
                    Row(Modifier.fillMaxWidth().clickable {
                        val chatId = listOf(uid, person.uid).sorted().joinToString("_")
                        val data = mapOf("participants" to listOf(uid, person.uid), "lastMessage" to "Say hello", "otherName_$uid" to person.name, "otherName_${person.uid}" to (FirebaseAuth.getInstance().currentUser?.displayName ?: "DHANU user"), "updatedAt" to FieldValue.serverTimestamp())
                        db.collection("chats").document(chatId).set(data, com.google.firebase.firestore.SetOptions.merge()).addOnSuccessListener { onOpen(ChatRow(chatId, person.uid, person.name, "Say hello")) }.addOnFailureListener { error = it.localizedMessage ?: "Could not start chat" }
                    }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(person.name); Spacer(Modifier.width(10.dp)); Column { Text(person.name, color = Soft, fontWeight = FontWeight.SemiBold); Text(person.email, color = Muted, fontSize = 11.sp) }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("YOUR CHATS", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 10.dp))
        if (chats.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.ChatBubble, null, tint = Purple, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(12.dp)); Text("Your conversations start here", color = Soft, fontWeight = FontWeight.SemiBold); Text("Search a friend's email to send a message", color = Muted, fontSize = 12.sp) } }
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats) { chat -> Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { onOpen(chat) }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Avatar(chat.otherName); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(chat.otherName, color = Soft, fontWeight = FontWeight.Bold); Text(chat.lastMessage, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp) }; Text("›", color = Pink, fontSize = 28.sp) } }
        }
    }
}

@Composable
fun Avatar(name: String) {
    Box(Modifier.size(46.dp).background(Brush.linearGradient(listOf(Purple, Pink)), CircleShape), contentAlignment = Alignment.Center) { Text(name.firstOrNull()?.uppercase() ?: "D", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp) }
}

@Composable
fun ConversationScreen(me: String, chat: ChatRow, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var draft by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    DisposableEffect(chat.id) {
        val listener = db.collection("chats").document(chat.id).collection("messages").orderBy("sentAt", Query.Direction.ASCENDING).addSnapshotListener { snap, e ->
            if (e != null) { error = e.localizedMessage ?: "Could not load messages"; return@addSnapshotListener }
            messages = snap?.documents.orEmpty().map { d -> ChatMessage(d.id, d.getString("senderId") ?: "", d.getString("text") ?: "", d.getTimestamp("sentAt")?.toDate()?.time ?: 0L) }
        }
        onDispose { listener.remove() }
    }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17102A), Ink)))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Soft) }
            Avatar(chat.otherName); Spacer(Modifier.width(10.dp)); Column { Text(chat.otherName, color = Soft, fontWeight = FontWeight.Bold); Text("DHANU MESSENGER", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp) }
        }
        HorizontalDivider(color = Color(0xFF302442))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), reverseLayout = false, contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(messages) { msg ->
                val mine = msg.senderId == me
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Column(Modifier.widthIn(max = 290.dp).background(if (mine) Brush.linearGradient(listOf(Purple, Color(0xFF7545D5))) else Brush.linearGradient(listOf(Color(0xFF29223B), Color(0xFF211B31))), RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text(msg.text, color = Color.White, fontSize = 15.sp)
                        if (msg.sentAt > 0) Text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(msg.sentAt)), color = Color.White.copy(alpha = .65f), fontSize = 9.sp, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
                    }
                }
            }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9CBA), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp))
        Row(Modifier.fillMaxWidth().padding(12.dp).background(Panel, RoundedCornerShape(24.dp)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextField(draft, { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Write a message...", color = Muted) }, maxLines = 4, colors = TextFieldDefaults.colors(focusedTextColor = Soft, unfocusedTextColor = Soft, focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Pink))
            IconButton(enabled = draft.isNotBlank() && !sending, onClick = {
                val text = draft.trim(); if (text.isEmpty()) return@IconButton
                sending = true
                db.collection("chats").document(chat.id).collection("messages").add(mapOf("senderId" to me, "text" to text, "sentAt" to FieldValue.serverTimestamp())).addOnSuccessListener {
                    db.collection("chats").document(chat.id).update("lastMessage", text, "updatedAt", FieldValue.serverTimestamp())
                    draft = ""; sending = false
                }.addOnFailureListener { error = it.localizedMessage ?: "Message failed"; sending = false }
            }) { Icon(Icons.Default.Send, "Send", tint = if (draft.isNotBlank()) Pink else Muted) }
        }
    }
}
