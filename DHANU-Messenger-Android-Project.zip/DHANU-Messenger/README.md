# DHANU Messenger — Android starter project

A native Android Kotlin + Jetpack Compose messaging app starter with Firebase Email/Password Authentication and Cloud Firestore live chat.

## Included in this project
- Animated neon D brand mark
- Email/password registration and login
- User profile document creation
- Find another user by their exact registered email
- Start a one-to-one conversation
- Live Firestore message stream
- Dark purple/pink interface

## Important
This is a working starter/MVP source project, not a prebuilt APK. You must connect your own Firebase project and build/sign the APK. Firebase is the online backend; without it, accounts and cross-phone messaging will not work. Do not share your Firebase service-account keys or passwords.

## 1. Create Firebase project
1. Open https://console.firebase.google.com/ in Chrome and sign in with your Google account.
2. Create a project named `DHANU Messenger`.
3. Add an Android app. Android package/application ID must be exactly `com.dhanu.messenger`.
4. Download `google-services.json`.
5. Put that file in this project's `app/` folder (same folder as `app/build.gradle.kts`). Do not rename it.
6. In Firebase Console → Authentication → Get started → Sign-in method, enable **Email/Password**.
7. In Firebase Console → Firestore Database → Create database. Start in production mode.
8. Open Firestore Rules and replace them with the contents of `firebase/firestore.rules`, then Publish.

## 2. Build on an Android phone
A convenient phone-only route is AndroidIDE (an Android IDE app that supports Gradle projects). Availability and compatibility can vary by Android version/device.
1. Install AndroidIDE from its official project/release page. Avoid unofficial APK download sites.
2. Extract `DHANU-Messenger.zip` into a folder on your phone.
3. Copy your Firebase `google-services.json` into `DHANU-Messenger/app/`.
4. Open/import the extracted project folder in AndroidIDE.
5. Allow Gradle sync and install any requested Android SDK/build tools. Use JDK 17.
6. Run the `app` configuration on your phone, or use the Gradle task `:app:assembleDebug`.
7. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`. Tap it to install; allow installation from that source if Android asks.

If AndroidIDE cannot build this project on your device, use a computer with Android Studio (JDK 17, Android SDK 35): open the project folder, add `google-services.json`, sync Gradle, then Build → Build APK(s).

## 3. Test between two phones
1. Install the same APK on both phones.
2. Register two different accounts with two different email addresses.
3. On phone A, search for phone B's exact registered email and tap the result.
4. Send a message. The message should appear on phone B while both phones have internet access.

## Security and production notes
- Firestore rules restrict chat reads and writes to conversation participants.
- User lookup currently uses exact email matching; this is a basic MVP, not a public directory/search service.
- Do not store passwords in Firestore. Firebase Authentication handles passwords.
- Before public release, add email verification, password reset, profile/photo storage, abuse reporting/blocking, rate limits/App Check, privacy policy, and stronger validation for chat participant membership and chat metadata updates.
- The current app supports text messaging. Image/video upload, voice notes, push notifications, typing presence, and read receipts are planned enhancements, not implemented in this starter.
